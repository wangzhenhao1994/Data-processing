%%
cd BorisSB/1;
qm_run;
cd ../..; 
%%
cd BorisSB/2;
qm_run;
cd ../..; 
%%
cd BorisSB/3;
qm_run;
cd ../..; 

%%
cd Werschnik/OVL_0-1;
qm_run;
cd ../..; 
%%
cd Werschnik/PRJ_0-1;
qm_run;
cd ../..; 

