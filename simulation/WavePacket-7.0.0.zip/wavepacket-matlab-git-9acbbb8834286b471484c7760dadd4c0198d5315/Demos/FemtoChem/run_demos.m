%%
cd HOD/1;
qm_run;
cd ../..;
%% At the moment, the optimal control demo example doesn't work
% cd HOD/2;
% qm_run;
% cd ../..;
%%
cd HOD/3;
qm_run;
cd ../..;

%%
cd Interferometry/1;
qm_run;
cd ../..;
%%
cd Interferometry/2;
qm_run;
cd ../..;
%%
cd Interferometry/3;
qm_run;
cd ../..;
