%% Solve the TDSE in PDE setting
qm_setup('wave'); 
qm_init;    
qm_propa;
qm_cleanup;
