%%
cd Bound_2D/1;
qm_setup('wave'); qm_init(); qm_bound(); qm_cleanup();
cd ../..;
