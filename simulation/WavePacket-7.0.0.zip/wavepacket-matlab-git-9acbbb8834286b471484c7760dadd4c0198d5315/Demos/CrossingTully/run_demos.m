%%
cd Double/1;
qm_setup('wave'); qm_init(); qm_propa(); qm_cleanup(); % Quantum wave packet
qm_setup('fssh'); qm_init(); qm_propa(); qm_cleanup(); % Tully's fewest switches
qm_setup('sssh'); qm_init(); qm_propa(); qm_cleanup(); % Lasser's single switch
cd ../..;
%%
cd Double/2;
qm_setup('wave'); qm_init(); qm_propa(); qm_cleanup(); % Quantum wave packet
qm_setup('fssh'); qm_init(); qm_propa(); qm_cleanup(); % Tully's fewest switches
qm_setup('sssh'); qm_init(); qm_propa(); qm_cleanup(); % Lasser's single switch
cd ../..;
%%
cd Double/3;
qm_setup('wave'); qm_init(); qm_propa(); qm_cleanup(); % Quantum wave packet
qm_setup('fssh'); qm_init(); qm_propa(); qm_cleanup(); % Tully's fewest switches
qm_setup('sssh'); qm_init(); qm_propa(); qm_cleanup(); % Lasser's single switch
cd ../..;



%%
cd Extended/1;
qm_setup('wave'); qm_init(); qm_propa(); qm_cleanup(); % Quantum wave packet
qm_setup('fssh'); qm_init(); qm_propa(); qm_cleanup(); % Tully's fewest switches
qm_setup('sssh'); qm_init(); qm_propa(); qm_cleanup(); % Lasser's single switch
cd ../..;

%%
cd Single/1;
qm_setup('wave'); qm_init(); qm_propa(); qm_cleanup(); % Quantum wave packet
qm_setup('fssh'); qm_init(); qm_propa(); qm_cleanup(); % Tully's fewest switches
qm_setup('sssh'); qm_init(); qm_propa(); qm_cleanup(); % Lasser's single switch
cd ../..;
%%
cd Single/2;
qm_setup('wave'); qm_init(); qm_propa(); qm_cleanup(); % Quantum wave packet
qm_setup('fssh'); qm_init(); qm_propa(); qm_cleanup(); % Tully's fewest switches
qm_setup('sssh'); qm_init(); qm_propa(); qm_cleanup(); % Lasser's single switch
cd ../..;
%%
cd Single/3;
qm_setup('wave'); qm_init(); qm_propa(); qm_cleanup(); % Quantum wave packet
qm_setup('fssh'); qm_init(); qm_propa(); qm_cleanup(); % Tully's fewest switches
qm_setup('sssh'); qm_init(); qm_propa(); qm_cleanup(); % Lasser's single switch
cd ../..;
%%
cd Single/4;
qm_setup('wave'); qm_init(); qm_propa(); qm_cleanup(); % Quantum wave packet
qm_setup('fssh'); qm_init(); qm_propa(); qm_cleanup(); % Tully's fewest switches
qm_setup('sssh'); qm_init(); qm_propa(); qm_cleanup(); % Lasser's single switch
cd ../..;
