qm_setup();
aux.qm_BTversusH2 ('lvne', 36, [20 10 5], [20 10 05], [20 10 05], 0);
saveas(36, 'comparison.jpg');
