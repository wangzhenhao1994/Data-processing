%%
cd PendularStates/1;
qm_run;
cd ../..
%%
cd PendularStates/2;
qm_run;
cd ../..
%%
cd PendularStates/3;
qm_run;
cd ../..
%%
cd PendularStates/4;
qm_run;
cd ../..
%%
cd PendularStates/5;
qm_run;
cd ../..

%%
cd Test_DVR/1;
qm_run;
cd ../..
%%
cd Test_DVR/2;
qm_run;
cd ../..
%%
cd Test_DVR/3;
qm_run;
cd ../..
