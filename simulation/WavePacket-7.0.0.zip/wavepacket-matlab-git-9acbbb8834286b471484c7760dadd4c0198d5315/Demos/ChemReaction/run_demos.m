%%
cd D2F/1;
qm_setup('wave'); qm_init(); qm_propa(); qm_cleanup();
cd ../..;
%%
cd D2F/2;
qm_setup('wave'); qm_init(); qm_propa(); qm_cleanup();
cd ../..;
