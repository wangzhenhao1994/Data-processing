% Copyright (C) 2004-2007 Burkhard Schmidt's group
%               2008 Ulf Lorenz
%               2011 Ulf Lorenz
%
% This file is under public domain. You may modify or incorporate it into other
% works without any restrictions.

function qm_init
global hamilt plots space

log.disp ( '*****************************' )
log.disp ( 'H2+' )
log.disp ( '*****************************' )

% Spatial discretization
space.dof{1} = grid.fft;% using fft grid
space.dof{1}.mass = (2.01533/2)^2/2.01533;            % Reduced mass
space.dof{1}.n_pts = 1280*3;                % Number of grid points
space.dof{1}.x_min =  1.0;               % Lower bound of grid 
space.dof{1}.x_max = 100;               % Upper bound of grid
space.dof{1}.periodic = false;           % Build the kinetic energy matrix
                                         % without periodic boundary conditions
% Hamiltonian operator 
hamilt.truncate.e_min  =  -0.2;           % Lower truncation of energy
hamilt.truncate.e_max  =  20.0;           % Upper truncation of energy

for m=1:2
hamilt.pot{m,m}      = pot.interp;        % Harmonic oscillator
% Select eigen/values/functions
hamilt.eigen.start     = 00;             % Lower index
hamilt.eigen.stop      = 30;             % Upper index
end



% Plot time evolution of expectation values
%plots.expect          = vis.expect;
%plots.expect.e_max    = 30;            % Manually set range for energy plot
