qm_setup(); 
qm_init(); 
qm_bound();
qm_cleanup();
